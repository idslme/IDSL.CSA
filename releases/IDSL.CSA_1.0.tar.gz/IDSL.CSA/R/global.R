utils::globalVariables(c("i", "MetaVariable1"))
